﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace provaDW2.Controllers
{
    public class CutController : Controller
    {
       CutDAO cutDAO = new CutDAO();


        public static List<Cut> listaCut = new List<Cut>();

        // GET: Cut
        public ActionResult Index()
        {
                listaCut = cutDAO.List();
                return View(listaCut);
        }

        // GET: Cut/Details/5
        public ActionResult Details(int id)
        {
            var cut = listaCut.Single(p => p.id == id);
            return View(cut);
        }

        // GET: Cut/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Cut/Create
        [HttpPost]
        public ActionResult Create(Cut cut)
        {
            try
            {
                // TODO: Add insert logic here
                listaCut.Add(cut);
                cutDAO.Create(cut);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Cut/Edit/5
        public ActionResult Edit(int id)
        {
            var cut = listaCut.Single(p => p.id == id);
            return View(cut);
        }

        // POST: Cut/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                var cut = listaCut.Single(p => p.id == id);
                if (TryUpdateModel(cut))
                {
                    cutDAO.Edit(cut);
                    return RedirectToAction("Index");
                }
                return View(cut);
            }
            catch
            {
                return View();
            }
        }

        // GET: Cut/Delete/5
        public ActionResult Delete(int id)
        {
            var cut = listaCut.Single(p => p.id == id);
            return View(cut);
        }

        // POST: Cut/Delete/5
        [HttpPost]
        public ActionResult Delete(Cut cut)
        {
            try
            {
                // TODO: Add delete logic here
                listaCut.Remove(cut);
                cutDAO.Delete(cut);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
