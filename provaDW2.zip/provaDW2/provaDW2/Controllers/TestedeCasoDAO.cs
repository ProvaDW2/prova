﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using provaDW2.Models;
using provaDW2.Controllers;
using System.Data;

namespace provaDW2.Controllers
{
    public class TestedeCasoDAO
    {



        public bool Create(TestedeCaso tc)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (tc != null)
                {
                    //DAO.AcessoDadosMySQL.AdicionarParametros("@intId", banda.Id);
                   // DAO.AcessoDadosMySQL.AdicionarParametros("@intId", tc.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchtestName", tc.nomedoteste);
                    string strSQL = "insert into TestCase (testName) values ( @vchtestName); SELECT LAST_INSERT_ID();";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<TestedeCaso> List()
        {
            List<TestedeCaso> lista = new List<TestedeCaso>();
            try
            {
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select id, testName from TestCase";
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    TestedeCaso objNovaBanda = new TestedeCaso();
                    objNovaBanda.id = objLinha["id"] != DBNull.Value ? Convert.ToInt32(objLinha["id"]) : 0;
                    objNovaBanda.nomedoteste = objLinha["testName"] != DBNull.Value ? Convert.ToString(objLinha["testName"]) : "";
                    lista.Add(objNovaBanda);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
        }

        public bool Edit(TestedeCaso tc)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (tc != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", tc.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchtestName", tc.nomedoteste);
                    string strSQL = "update TestCase set testName = @vchtestName where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(TestedeCaso tc)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (tc != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", tc.id);
                    string strSQL = "delete from TestCase where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}