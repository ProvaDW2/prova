﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using provaDW2.Models;
using System.Data;

namespace provaDW2.Controllers
{
    public class TesteHierarquicoDAO
    {
        public bool Create(TesteHierarquico th)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (th != null)
                {
                    //DAO.AcessoDadosMySQL.AdicionarParametros("@intId", banda.Id);
                    // DAO.AcessoDadosMySQL.AdicionarParametros("@intId", tc.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchnivel", th.nivel);
                    string strSQL = "insert into TestHierarchical (nivel) values (@vchnivel); SELECT LAST_INSERT_ID();";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<TestedeCaso> List()
        {
            List<TestedeCaso> lista = new List<TestedeCaso>();
            try
            {
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select id, nivel from TestHierarchical";
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    TestedeCaso objNovaBanda = new TestedeCaso();
                    objNovaBanda.id = objLinha["id"] != DBNull.Value ? Convert.ToInt32(objLinha["id"]) : 0;
                    objNovaBanda.nomedoteste = objLinha["nivel"] != DBNull.Value ? Convert.ToString(objLinha["nivel"]) : "";
                    lista.Add(objNovaBanda);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
        }

        public bool Edit(TesteHierarquico th)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (th != null)
                {
                  //  DAO.AcessoDadosMySQL.AdicionarParametros("@intid", th.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchnivel", th.nivel);
                    string strSQL = "update TestHierarchical set nivel = @vchnivel where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(TesteHierarquico th)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (th != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", th.id);
                    string strSQL = "delete from TestHierarchical where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}