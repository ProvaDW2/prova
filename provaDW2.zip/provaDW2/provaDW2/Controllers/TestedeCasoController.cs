﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using provaDW2.Models;

namespace provaDW2.Controllers
{
    public class TestedeCasoController : Controller
    {
        public static TestedeCaso tcdao = new TestedeCaso();
        public static List<TestedeCaso> listaTc = new List<TestedeCaso>();
        
        public static List<TestedeCaso> testesdecaso = new List<TestedeCaso>{
         new TestedeCaso {
                id = 1,
                nomedoteste = "teste1",
                classe = "classe1",
                pacote = "pacote1",
                //listadependencias = new List<Dependencia>() { "assad" },
                
            },
           new TestedeCaso {
                id = 2,
                nomedoteste = "teste2",
                classe = "classe2",
                pacote = "pacote2",
                
          },
    };

        //
        // GET: /TesteHierarquico/
        public ActionResult Index()
        {
           /* var testes = from b in testesdecaso
                         orderby b.id
                         select b;*/
            listaTc.Add(tcdao);
            return View(listaTc);
        }

        //
        // GET: /TestedeCaso/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /TestedeCaso/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /TestedeCaso/Create
        [HttpPost]
        public ActionResult Create(TestedeCaso teste)
        {
            try
            {
                testesdecaso.Add(teste);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /TestedeCaso/Edit/5
        public ActionResult Edit(int id)
        {
            var teste = testesdecaso.Single(t => t.id == id);
            return View(teste);
        }

        //
        // POST: /TestedeCaso/Edit/5
        [HttpPost]
        public ActionResult Edit(TestedeCaso teste)
        {
            try
            {
                testesdecaso.Add(teste);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /TestedeCaso/Delete/5
        public ActionResult Delete(int id)
        {
            var teste = testesdecaso.Single(t => t.id == id);
            return View(teste);
        }

        //
        // POST: /TestedeCaso/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                var teste = testesdecaso.Single(t => t.id == id);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
