﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace provaDW2.Controllers
{
    public class TestScaffoldingController : Controller
    {
       TestScaffoldingDAO testScaffoldingDAO = new TestScaffoldingDAO();


        public static List<TestScaffolding> listaTestScaffolding = new List<TestScaffolding>();

        // GET: TestScaffolding
        public ActionResult Index()
        {
                listaTestScaffolding = testScaffoldingDAO.List();
                return View(listaTestScaffolding);
        }

        // GET: TestScaffolding/Details/5
        public ActionResult Details(int id)
        {
            var testScaffolding = listaTestScaffolding.Single(p => p.Id == id);
            return View(testScaffolding);
        }

        // GET: TestScaffolding/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TestScaffolding/Create
        [HttpPost]
        public ActionResult Create(TestScaffolding testScaffolding)
        {
            try
            {
                // TODO: Add insert logic here
                testScaffoldingDAO.Create(testScaffolding);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: TestScaffolding/Edit/5
        public ActionResult Edit(int id)
        {
            var testScaffolding = listaTestScaffolding.Single(p => p.Id == id);
            return View(testScaffolding);
        }

        // POST: TestScaffolding/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                var testScaffolding = listaTestScaffolding.Single(p => p.Id == id);
                if (TryUpdateModel(testScaffolding))
                {
                    testScaffoldingDAO.Edit(testScaffolding);
                    return RedirectToAction("Index");
                }
                return View(testScaffolding);
            }
            catch
            {
                return View();
            }
        }

        // GET: TestScaffolding/Delete/5
        public ActionResult Delete(int id)
        {
            var testScaffolding = listaTestScaffolding.Single(p => p.Id == id);
            return View(testScaffolding);
        }

        // POST: TestScaffolding/Delete/5
        [HttpPost]
        public ActionResult Delete(TestScaffolding testScaffolding)
        {
            try
            {
                // TODO: Add delete logic here
                listaTestScaffolding.Remove(testScaffolding);
                testScaffoldingDAO.Delete(testScaffolding);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
