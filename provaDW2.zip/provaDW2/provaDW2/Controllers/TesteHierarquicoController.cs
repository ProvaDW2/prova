﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using provaDW2.Models;

namespace provaDW2.Controllers
{
    public class TesteHierarquicoController : Controller
    {
        
        public static List<TesteHierarquico> listahierarquicos = new List<TesteHierarquico>{
         new TesteHierarquico {

                id = 1,
                nivel = "facil"
            },
           new TesteHierarquico {
                id = 2,
                nivel = "dificil"
          },
    };
        //
        // GET: /TesteHierarquico/
        public ActionResult Index()
        {
            
             var testes = from b in listahierarquicos
             orderby b.id
             select b;
             return View(testes);
        }

        //
        // GET: /TesteHierarquico/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /TesteHierarquico/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /TesteHierarquico/Create
        [HttpPost]
        public ActionResult Create(TesteHierarquico testehierarquico)
        {
            try
            {
                listahierarquicos.Add(testehierarquico);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /TesteHierarquico/Edit/5
        public ActionResult Edit(int id)
        {
            var teste = listahierarquicos.Single(t => t.id == id);
            return View(teste);
        }

        //
        // POST: /TesteHierarquico/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                var teste = listahierarquicos.Single(t => t.id == id);
                if (TryUpdateModel(teste)) {

                    return RedirectToAction("Index"); 
                }
                return View(teste);
                
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /TesteHierarquico/Delete/5
        public ActionResult Delete(int id)
        {
            var teste = listahierarquicos.Single(t => t.id == id);
            return View(teste);
        }

        //
        // POST: /TesteHierarquico/Delete/5
        [HttpPost]
        public ActionResult Delete(TesteHierarquico teste)
        {
            try
            {
                listahierarquicos.Remove(teste);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
