﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace provaDW2.Controllers
{
    public class HardwareController : Controller
    {
        //lista com os hardwares cadastrados
        HardwareDAO hardwareDAO = new HardwareDAO();
        public static List<Hardware> listaHardware = new List<Hardware>();

        // GET: /Hardware/
        public ActionResult Index()
        {
            listaHardware = hardwareDAO.List();
            return View(listaHardware);
        }

        //
        // GET: /Hardware/Details/5
        public ActionResult Details(int id)
        {
            var hardware = listaHardware.Single(p => p.Id == id);
            return View(hardware);
        }

        //
        // GET: /Hardware/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Hardware/Create
        [HttpPost]
        public ActionResult Create(Hardware hardware)
        {
            try
            {
                // TODO: Add insert logic here
                listaHardware.Add(hardware);
                hardwareDAO.Create(hardware);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Hardware/Edit/5
        public ActionResult Edit(int id)
        {
            var hardware = listaHardware.Single(p => p.Id == id);
            return View(hardware);
        }

        //
        // POST: /Hardware/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Hardware hardware)
        {
            try
            {
                // TODO: Add update logic here
                hardware = listaHardware.Single(p => p.Id == id);
                if (TryUpdateModel(hardware))
                {
                    hardwareDAO.Edit(hardware);
                    return RedirectToAction("Index");
                }
                return View(hardware);
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Hardware/Delete/5
        public ActionResult Delete(int id)
        {
            var hardware = listaHardware.Single(p => p.Id == id);
            return View();
        }

        //
        // POST: /Hardware/Delete/5
        [HttpPost]
        public ActionResult Delete(Hardware hardware)
        {
            try
            {
                // TODO: Add delete logic here
                listaHardware.Remove(hardware);
                hardwareDAO.Delete(hardware);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
