﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace provaDW2.Controllers
{
    public class SoftwareController : Controller
    {
        //lista com os software cadastrados
        SoftwareDAO softwareDAO = new SoftwareDAO();
        public static List<Software> listaSoftware = new List<Software>();

        // GET: /Software/
        public ActionResult Index()
        {
            listaSoftware = softwareDAO.List();
            return View(listaSoftware);
        }

        //
        // GET: /Software/Details/5
        public ActionResult Details(int id)
        {
            var software = listaSoftware.Single(p => p.Id == id);
            return View(software);
        }

        //
        // GET: /Software/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Software/Create
        [HttpPost]
        public ActionResult Create(Software software)
        {
            try
            {
                // TODO: Add insert logic here
                listaSoftware.Add(software);
                softwareDAO.Create(software);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Software/Edit/5
        public ActionResult Edit(int id)
        {
            var software = listaSoftware.Single(p => p.Id == id);
            return View(software);
        }

        //
        // POST: /Software/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Software software)
        {
            try
            {
                // TODO: Add update logic here
                software = listaSoftware.Single(p => p.Id == id);
                if (TryUpdateModel(software))
                {
                    softwareDAO.Edit(software);
                    return RedirectToAction("Index");
                }
                return View(software);
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Software/Delete/5
        public ActionResult Delete(int id)
        {
            var software = listaSoftware.Single(p => p.Id == id);
            return View();
        }

        //
        // POST: /Software/Delete/5
        [HttpPost]
        public ActionResult Delete(Software software)
        {
            try
            {
                // TODO: Add delete logic here
                listaSoftware.Remove(software);
                softwareDAO.Delete(software);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
