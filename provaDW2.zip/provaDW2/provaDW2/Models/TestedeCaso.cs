﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace provaDW2.Models
{
    public class TestedeCaso
    {
        public int id { get; set; }
        public string nomedoteste { get; set; }
        public string classe { get; set; }
        public string pacote { get; set; }
        public List<Dependencia> listadependencias;
    }
}