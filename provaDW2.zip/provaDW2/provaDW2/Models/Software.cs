﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace provaDW2.Models
{
    public class Software
    {
        //declaração de atributos da classe Software

        public int Id; 

        [Display(Name="S.O")]
        public String OS { get; set; }

        [Display(Name = "Versão")] 
        public String SoftwareVersion {get; set;}
        
        [Display(Name = "Tipo")]
        public String Type {get; set;}

        [Display(Name = "Descrição")]
        public String Description {get; set;}
    }
}