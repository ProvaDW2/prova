﻿using provaDW2.Models;
using provaDW2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace provaDW2.Controllers
{
    public class HardwareDAO
    {
        public bool Create(Hardware hardware)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (hardware != null)
                {
                    //DAO.AcessoDadosMySQL.AdicionarParametros("@intId", hardware.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDeviceType", hardware.DeviceType);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchModelNumber", hardware.ModelNumber);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDescription", hardware.Description);
                    string strSQL = "insert into Hardware (deviceNumber, modelNumber, descricao) values ( @vchDeviceType, @vchModelNumber, @vchDescription); SELECT LAST_INSERT_ID();";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Hardware> List()
        {
            List<Hardware> lista = new List<Hardware>();
            try
            {
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select * from Hardware";
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    Hardware objNovoHardware = new Hardware();
                    objNovoHardware.Id = objLinha["Id"] != DBNull.Value ? Convert.ToInt32(objLinha["Id"]) : 0;
                    objNovoHardware.DeviceType = objLinha["DeviceType"] != DBNull.Value ? Convert.ToString(objLinha["DeviceType"]) : "";
                    objNovoHardware.ModelNumber = objLinha["ModelNumber"] != DBNull.Value ? Convert.ToString(objLinha["ModelNumber"]) : "";
                    objNovoHardware.Description = objLinha["Description"] != DBNull.Value ? Convert.ToString(objLinha["Description"]) : "";
                    lista.Add(objNovoHardware);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
        }

        public bool Edit(Hardware hardware)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (hardware != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intId", hardware.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDeviceType", hardware.DeviceType);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchModelNumber", hardware.ModelNumber);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDescription", hardware.Description);
                    string strSQL = "update Hardware set deviceNumber = @vchDeviceType, modelNumber = @vchModelNumber, descricao = @vchDescription where id = @intId; select @intId;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(Hardware hardware)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (hardware != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intId", hardware.Id);
                    string strSQL = "delete from Hardware where id = @intId; select @intId;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}