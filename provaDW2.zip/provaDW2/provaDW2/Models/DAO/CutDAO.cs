﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using provaDW2;
using System.Data;

namespace provaDW2.Controllers
{
    public class CutDAO
    {
        //metodo para criar uma nova row na tabela Cut do banco de dados
        public bool Create(Cut cut)
        {
            try
            {
                //limpa os parametros para serem adicionados novos parametros no banco
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (cut != null)
                {
                    //adiciona os parametros para a execução da query
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchid", cut.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchcomponenteNome", cut.componenteNome);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchpacote", cut.pacote);

                    //quey que será executada
                    string strSQL = "insert into cut (componentName, package) values (@vchcomponenteNome, @vchpacote); SELECT LAST_INSERT_id();";
                    //executa a query e coleta o retorno do metodo
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                // verificar o retorno do resultado
                int intResultado = 0;

                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        //lista do cut
        public List<Cut> List()
        {
            List<Cut> listaCut = new List<Cut>();
            try
            {
                DataTable objDataTable = null;
                //query de consulta 
                string strSQL = "select * from cut";
                //execução da query com o retorno da busca 
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return listaCut;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    Cut objNovoCut = new Cut();
                    objNovoCut.id = objLinha["id"] != DBNull.Value ? Convert.ToInt32(objLinha["id"]) : 0;
                    objNovoCut.componenteNome = objLinha["componentName"] != DBNull.Value ? Convert.ToString(objLinha["componentName"]) : "";
                    objNovoCut.pacote = objLinha["package"] != DBNull.Value ? Convert.ToString(objLinha["package"]) : "";
                    listaCut.Add(objNovoCut);
                }
                return listaCut;
            }
            catch (Exception)
            {
                return listaCut;
            }
        }

        public bool Edit(Cut cut)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (cut != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", cut.id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchcomponentName", cut.componenteNome);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchpacote", cut.pacote);
                    string strSQL = "update cut set componentName = @vchcomponentName, package = @vchpacote where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public bool Delete(Cut cut)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (cut != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", cut.id);
                    string strSQL = "delete from cut where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Cut GetById(int id)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;

                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", id);
                    string strSQL = "select * from cut where id = @intid";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);

                    Cut c = (Cut)objRetorno;
                    
               
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return c;
                }
                return c;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}