﻿using provaDW2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using provaDW2;
using System.Data;


namespace provaDW2.Controllers
{
    public class TestScaffoldingDAO
    {
        public bool Create(TestScaffolding TestScaffolding)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (TestScaffolding != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchid", TestScaffolding.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchnome", TestScaffolding.Nome);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchtipo", TestScaffolding.Tipo);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchclasse", TestScaffolding.Classe);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchpackage", TestScaffolding.Pacote);
                    string strSQL = "insert into TestScaffolding (id,nome,tipo,classe,package) values (@vchId,@vchNome,@vchtipo,@vchclasse,@vchpackage); SELECT LAST_INSERT_ID();";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<TestScaffolding> List()
        {
            List<TestScaffolding> lista = new List<TestScaffolding>();
            try
            {
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select * from TestScaffolding";
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    TestScaffolding objNovaIndicador = new TestScaffolding();
                    objNovaIndicador.Id = objLinha["id"] != DBNull.Value ? Convert.ToInt32(objLinha["Id"]) : 0;
                    objNovaIndicador.Nome = objLinha["nome"] != DBNull.Value ? Convert.ToString(objLinha["nome"]) : "";
                    objNovaIndicador.Tipo = objLinha["tipo"] != DBNull.Value ? Convert.ToString(objLinha["tipo"]) : "";
                    objNovaIndicador.Classe = objLinha["classe"] != DBNull.Value ? Convert.ToString(objLinha["classe"]) : "";
                    objNovaIndicador.Pacote = objLinha["package"] != DBNull.Value ? Convert.ToString(objLinha["package"]) : "";

                    lista.Add(objNovaIndicador);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
        }


        public bool Edit(TestScaffolding TestScaffolding)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (TestScaffolding != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intid", TestScaffolding.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchnome", TestScaffolding.Nome);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchtipo", TestScaffolding.Tipo);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchclasse", TestScaffolding.Classe);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchpackage", TestScaffolding.Pacote);
                    string strSQL = "update TestScaffolding set nome = @vchnome, tipo = @vchtipo, classe = @vchclasse , package = @vchpackage  where id = @intid; select @intId;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public bool Delete(TestScaffolding TestScaffolding)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (TestScaffolding != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intId", TestScaffolding.Id);
                    string strSQL = "delete from TestScaffolding where id = @intid; select @intid;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}