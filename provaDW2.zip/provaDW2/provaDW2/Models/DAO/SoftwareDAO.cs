﻿using provaDW2.Models;
using provaDW2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace provaDW2.Controllers
{
    public class SoftwareDAO
    {
        public bool Create(Software software)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (software != null)
                {
                    //DAO.AcessoDadosMySQL.AdicionarParametros("@intId", hardware.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchOS", software.OS);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchSoftwareVersion", software.SoftwareVersion);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchType", software.Type);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDescription", software.Description);
                    string strSQL = "insert into Software (os, softwareVersion, tipo, descricao) values ( @vchOS, @vchSoftwareVersion, @vchType, @vchDescription); SELECT LAST_INSERT_ID();";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Software> List()
        {
            List<Software> lista = new List<Software>();
            try
            {
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select * from Software";
                objDataTable = DAO.AcessoDadosMySQL.ExecutaConsultar(System.Data.CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    Software objNovoSoftware = new Software();
                    objNovoSoftware.Id = objLinha["Id"] != DBNull.Value ? Convert.ToInt32(objLinha["Id"]) : 0;
                    objNovoSoftware.OS = objLinha["OS"] != DBNull.Value ? Convert.ToString(objLinha["OS"]) : "";
                    objNovoSoftware.SoftwareVersion = objLinha["SoftwareVersion"] != DBNull.Value ? Convert.ToString(objLinha["SoftwareVersion"]) : "";
                    objNovoSoftware.Type = objLinha["Type"] != DBNull.Value ? Convert.ToString(objLinha["Type"]) : "";
                    objNovoSoftware.Description = objLinha["Description"] != DBNull.Value ? Convert.ToString(objLinha["Description"]) : "";
                    lista.Add(objNovoSoftware);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
        }

        public bool Edit(Software software)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (software != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intId", software.Id);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchOS", software.OS);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchSoftwareVersion", software.SoftwareVersion);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchType", software.Type);
                    DAO.AcessoDadosMySQL.AdicionarParametros("@vchDescription", software.Description);
                    string strSQL = "update Software set os = @vchOS, softwareVersion = @vchSoftwareVersion, tipo = @vchType, descricao = @vchDescription where id = @intId; select @intId;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(Software software)
        {
            try
            {
                DAO.AcessoDadosMySQL.LimparParametros();
                object objRetorno = null;
                if (software != null)
                {
                    DAO.AcessoDadosMySQL.AdicionarParametros("@intId", software.Id);
                    string strSQL = "delete from Software where id = @intId; select @intId;";
                    objRetorno = DAO.AcessoDadosMySQL.ExecutarManipulacao(CommandType.Text, strSQL);
                }
                int intResultado = 0;
                if (objRetorno != null)
                {
                    if (int.TryParse(objRetorno.ToString(), out intResultado))
                        return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}