﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace provaDW2.Models
{
    public class Cut
    {
        //declaração de variáveis
        public int id { get; set; }
        public string componenteNome { get; set; }
        public string pacote { get; set; }
    }

}