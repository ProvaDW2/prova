﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace provaDW2.Models
{
    public class TesteHierarquico
    {
        public int id { get; set; }
        public string nivel { get; set; }
    }
}