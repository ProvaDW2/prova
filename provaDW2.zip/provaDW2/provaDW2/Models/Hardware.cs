﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace provaDW2.Models
{
    public class Hardware
    {
        //declaração de atributos da classe Hardware
        public int Id;

        [Display(Name = "Tipo")]
        public String DeviceType {get; set;}

        [Display(Name = "Número")]
        public String ModelNumber { get; set; }

        [Display(Name = "Descrição")]
        public String Description { get; set; }
    }
}